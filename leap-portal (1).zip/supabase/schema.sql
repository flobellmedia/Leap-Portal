-- The Leap — Client Portal schema
-- Run this in the Supabase SQL editor for your project.

-- 0. Invites — one row per enrolled client, created by Francesca before
-- she sends the welcome email. The client redeems the code once, right
-- after creating their own account, to activate their program.
create table if not exists invites (
  code text primary key,
  email text,
  full_name text,
  program_type text check (program_type in ('1-month', '4-month')) not null,
  redeemed boolean default false,
  redeemed_at timestamptz,
  created_at timestamptz default now()
);

-- RLS is enabled with NO policies below, which blocks all direct access
-- via the API (both anon and authenticated). The only way in or out of
-- this table is the redeem_invite() function, which runs as the table
-- owner and bypasses RLS — this keeps invite codes and client emails
-- from ever being readable by a signed-in client directly.
alter table invites enable row level security;

-- 1. Profiles (one row per client, linked to their auth account)
create table if not exists profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  full_name text,
  program_type text check (program_type in ('1-month', '4-month')),
  start_date date,
  archetype text,
  created_at timestamptz default now()
);

alter table profiles enable row level security;

create policy "Users can view their own profile"
  on profiles for select
  using (auth.uid() = id);

create policy "Users can update their own profile"
  on profiles for update
  using (auth.uid() = id);

-- 2. Milestones (per-client, grouped by pillar)
create table if not exists milestones (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references profiles (id) on delete cascade,
  pillar text check (pillar in ('relationships', 'money', 'identity')) not null,
  title text not null,
  description text,
  week_number int default 1,
  completed boolean default false,
  completed_at timestamptz,
  created_at timestamptz default now()
);

alter table milestones enable row level security;

create policy "Users can view their own milestones"
  on milestones for select
  using (auth.uid() = profile_id);

create policy "Users can update their own milestones"
  on milestones for update
  using (auth.uid() = profile_id);

-- 3. Resources (shared library, visible to all signed-in clients)
create table if not exists resources (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  url text not null,
  pillar text check (pillar in ('relationships', 'money', 'identity', 'general')),
  program_type text check (program_type in ('1-month', '4-month', 'both')) default 'both',
  created_at timestamptz default now()
);

alter table resources enable row level security;

create policy "Any signed-in user can view resources"
  on resources for select
  using (auth.role() = 'authenticated');

-- 4. Journal entries (private reflections per client)
create table if not exists journal_entries (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references profiles (id) on delete cascade,
  content text not null,
  created_at timestamptz default now()
);

alter table journal_entries enable row level security;

create policy "Users can view their own journal entries"
  on journal_entries for select
  using (auth.uid() = profile_id);

create policy "Users can insert their own journal entries"
  on journal_entries for insert
  with check (auth.uid() = profile_id);

-- 5. Calls (upcoming session info per client)
create table if not exists calls (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references profiles (id) on delete cascade,
  scheduled_at timestamptz not null,
  zoom_link text,
  notes text,
  created_at timestamptz default now()
);

alter table calls enable row level security;

create policy "Users can view their own calls"
  on calls for select
  using (auth.uid() = profile_id);

-- 6. redeem_invite() — called by the client right after they sign up
-- with their own email + password. Validates the code, creates their
-- profile row, and marks the invite used. SECURITY DEFINER means it
-- runs with the privileges of the function owner (not the calling
-- client), so it can read/write the otherwise-locked invites table.
create or replace function redeem_invite(p_code text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_invite invites%rowtype;
begin
  select * into v_invite from invites where code = p_code and redeemed = false;

  if not found then
    raise exception 'Invalid or already-used invite code';
  end if;

  insert into profiles (id, full_name, program_type)
  values (auth.uid(), v_invite.full_name, v_invite.program_type)
  on conflict (id) do nothing;

  update invites set redeemed = true, redeemed_at = now() where code = p_code;
end;
$$;

grant execute on function redeem_invite(text) to authenticated;

-- Note: there are no insert/update policies for clients on milestones,
-- resources, or calls beyond what's above — those are managed by you
-- (Francesca) directly in the Supabase table editor, or via a future
-- admin view. Clients can only toggle milestone completion, add their
-- own journal entries, and redeem their own invite code.
