import { useEffect, useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../supabaseClient'
import ProgressRing from '../components/ProgressRing'
import MilestoneList from '../components/MilestoneList'
import ResourceLibrary from '../components/ResourceLibrary'
import JournalPanel from '../components/JournalPanel'

const PROGRAM_LABELS = {
  '1-month': 'The 1-Month Shift',
  '4-month': 'The 4-Month Shift',
}

function pillarPercent(milestones, pillar) {
  const items = milestones.filter((m) => m.pillar === pillar)
  if (!items.length) return 0
  const done = items.filter((m) => m.completed).length
  return (done / items.length) * 100
}

export default function Dashboard({ profile }) {
  const { session, signOut } = useAuth()
  const [milestones, setMilestones] = useState([])
  const [resources, setResources] = useState([])
  const [journalEntries, setJournalEntries] = useState([])
  const [nextCall, setNextCall] = useState(null)
  const [loading, setLoading] = useState(true)

  const userId = session?.user?.id

  useEffect(() => {
    if (!userId) return

    const loadAll = async () => {
      setLoading(true)

      const [
        { data: milestoneData },
        { data: resourceData },
        { data: journalData },
        { data: callData },
      ] = await Promise.all([
        supabase.from('milestones').select('*').eq('profile_id', userId),
        supabase.from('resources').select('*').order('created_at', { ascending: true }),
        supabase
          .from('journal_entries')
          .select('*')
          .eq('profile_id', userId)
          .order('created_at', { ascending: false }),
        supabase
          .from('calls')
          .select('*')
          .eq('profile_id', userId)
          .gte('scheduled_at', new Date().toISOString())
          .order('scheduled_at', { ascending: true })
          .limit(1)
          .maybeSingle(),
      ])

      setMilestones(milestoneData || [])
      setResources(resourceData || [])
      setJournalEntries(journalData || [])
      setNextCall(callData)
      setLoading(false)
    }

    loadAll()
  }, [userId])

  const toggleMilestone = async (milestone) => {
    const updated = { ...milestone, completed: !milestone.completed }
    setMilestones((prev) => prev.map((m) => (m.id === milestone.id ? updated : m)))

    await supabase
      .from('milestones')
      .update({
        completed: updated.completed,
        completed_at: updated.completed ? new Date().toISOString() : null,
      })
      .eq('id', milestone.id)
  }

  const addJournalEntry = async (content) => {
    const { data, error } = await supabase
      .from('journal_entries')
      .insert({ profile_id: userId, content })
      .select()
      .single()

    if (!error && data) {
      setJournalEntries((prev) => [data, ...prev])
    }
  }

  if (loading) {
    return <div className="loading-screen">Gathering your progress…</div>
  }

  const overallPercent = milestones.length
    ? (milestones.filter((m) => m.completed).length / milestones.length) * 100
    : 0

  return (
    <div className="dashboard-shell">
      <header className="dashboard-header">
        <div className="header-brand">
          <span className="header-script">Leap</span>
          <span className="eyebrow header-eyebrow">With Francesca</span>
        </div>
        <div className="header-right">
          {profile?.program_type && (
            <span className="program-badge">{PROGRAM_LABELS[profile.program_type]}</span>
          )}
          <button className="ghost" onClick={signOut}>
            Sign Out
          </button>
        </div>
      </header>

      <section className="welcome-block">
        <h2 className="display">
          Welcome back{profile?.full_name ? `, ${profile.full_name.split(' ')[0]}` : ''}
        </h2>
        <div className="hairline welcome-rule" />
        {nextCall && (
          <p className="next-call">
            Your next call is{' '}
            <strong>
              {new Date(nextCall.scheduled_at).toLocaleString(undefined, {
                weekday: 'long',
                month: 'short',
                day: 'numeric',
                hour: 'numeric',
                minute: '2-digit',
              })}
            </strong>
            {nextCall.zoom_link && (
              <>
                {' '}
                —{' '}
                <a href={nextCall.zoom_link} target="_blank" rel="noreferrer">
                  join link
                </a>
              </>
            )}
          </p>
        )}
      </section>

      <section className="rings-row">
        <ProgressRing percent={overallPercent} label="Overall" size={180} />
        <ProgressRing percent={pillarPercent(milestones, 'identity')} label="Identity" />
        <ProgressRing percent={pillarPercent(milestones, 'relationships')} label="Relationships" />
        <ProgressRing percent={pillarPercent(milestones, 'money')} label="Money" />
      </section>

      <div className="dashboard-grid">
        <div className="card">
          <div className="eyebrow">Progress</div>
          <h3 className="display card-title">Your Milestones</h3>
          <MilestoneList milestones={milestones} onToggle={toggleMilestone} />
        </div>

        <div className="card">
          <div className="eyebrow">Library</div>
          <h3 className="display card-title">Resources</h3>
          <ResourceLibrary resources={resources} />
        </div>

        <div className="card journal-card">
          <div className="eyebrow">Journal</div>
          <h3 className="display card-title">Reflections</h3>
          <JournalPanel entries={journalEntries} onAdd={addJournalEntry} />
        </div>
      </div>

      <style>{`
        .dashboard-shell {
          max-width: 980px;
          margin: 0 auto;
          padding: 3rem 1.5rem 4rem;
        }
        .dashboard-header {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          margin-bottom: 3rem;
          gap: 1rem;
          flex-wrap: wrap;
        }
        .header-brand {
          display: flex;
          flex-direction: column;
          line-height: 1;
        }
        .header-script {
          font-family: var(--font-script);
          font-size: 40px;
          color: var(--crimson);
        }
        .header-eyebrow {
          margin-top: 2px;
        }
        .header-right {
          display: flex;
          align-items: center;
          gap: 1rem;
        }
        .program-badge {
          font-family: var(--font-sans);
          font-size: 9px;
          letter-spacing: 0.2em;
          text-transform: uppercase;
          background: var(--crimson-tint);
          color: var(--crimson);
          padding: 0.55rem 0.9rem;
        }
        .welcome-block { margin-bottom: 2.5rem; }
        .welcome-block h2 { font-size: 1.75rem; }
        .welcome-rule { margin: 0.9rem 0 1.1rem; }
        .next-call { font-size: 0.95rem; }
        .rings-row {
          display: flex;
          flex-wrap: wrap;
          gap: 2rem;
          justify-content: center;
          margin-bottom: 3rem;
          padding: 2.5rem 2rem;
          background: var(--crimson-tint);
        }
        .dashboard-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1.5rem;
        }
        .journal-card { grid-column: span 2; }
        .card-title {
          font-size: 1.2rem;
          margin: 0.35rem 0 1.25rem;
        }
        @media (max-width: 720px) {
          .dashboard-grid { grid-template-columns: 1fr; }
          .journal-card { grid-column: span 1; }
        }
      `}</style>
    </div>
  )
}
