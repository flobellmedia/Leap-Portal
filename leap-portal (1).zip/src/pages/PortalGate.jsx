import { useCallback, useEffect, useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../supabaseClient'
import OnboardingGate from './OnboardingGate'
import Dashboard from './Dashboard'

export default function PortalGate() {
  const { session } = useAuth()
  const userId = session?.user?.id
  // undefined = checking, null = no profile yet, object = active client
  const [profile, setProfile] = useState(undefined)

  const checkProfile = useCallback(async () => {
    if (!userId) return
    const { data } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle()
    setProfile(data || null)
  }, [userId])

  useEffect(() => {
    checkProfile()
  }, [checkProfile])

  if (profile === undefined) {
    return <div className="loading-screen">Opening your portal…</div>
  }

  if (profile === null) {
    return <OnboardingGate onRedeemed={checkProfile} />
  }

  return <Dashboard profile={profile} />
}
