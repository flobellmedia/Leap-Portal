import { useState } from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../supabaseClient'

export default function AuthPage() {
  const { session, signIn } = useAuth()
  const [mode, setMode] = useState('signin') // 'signin' | 'signup'
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState(null)
  const [notice, setNotice] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  if (session) return <Navigate to="/" replace />

  const resetMessages = () => {
    setError(null)
    setNotice(null)
  }

  const handleSignIn = async (e) => {
    e.preventDefault()
    resetMessages()
    setSubmitting(true)
    const { error: signInError } = await signIn(email, password)
    setSubmitting(false)
    if (signInError) {
      setError('That email and password combination didn\u2019t work. Double-check and try again.')
    }
  }

  const handleSignUp = async (e) => {
    e.preventDefault()
    resetMessages()

    if (password.length < 8) {
      setError('Your password needs to be at least 8 characters.')
      return
    }
    if (password !== confirmPassword) {
      setError('Those passwords don\u2019t match.')
      return
    }

    setSubmitting(true)
    const { data, error: signUpError } = await supabase.auth.signUp({ email, password })
    setSubmitting(false)

    if (signUpError) {
      setError(signUpError.message)
      return
    }

    if (data.session) {
      // Email confirmation is off — they're signed in immediately and will
      // land on the invite-code step via PortalGate.
      return
    }

    setNotice('Check your email to confirm your account, then come back and sign in.')
    setMode('signin')
  }

  return (
    <div className="auth-shell">
      <div className="auth-panel">
        <div className="auth-brand">
          <span className="auth-script">Leap</span>
          <span className="auth-subscript">With Francesca</span>
        </div>

        <div className="auth-tabs">
          <button
            type="button"
            className={`link-tab ${mode === 'signin' ? 'active' : ''}`}
            onClick={() => {
              setMode('signin')
              resetMessages()
            }}
          >
            Sign In
          </button>
          <button
            type="button"
            className={`link-tab ${mode === 'signup' ? 'active' : ''}`}
            onClick={() => {
              setMode('signup')
              resetMessages()
            }}
          >
            Create Account
          </button>
        </div>

        <div className="hairline auth-rule" />

        {mode === 'signin' ? (
          <form onSubmit={handleSignIn} className="auth-form">
            <label className="field-label" htmlFor="email">
              Email
            </label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
            />

            <label className="field-label" htmlFor="password">
              Password
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="current-password"
            />

            {notice && <div className="form-notice">{notice}</div>}
            {error && <div className="form-error">{error}</div>}

            <button type="submit" className="primary auth-submit" disabled={submitting}>
              {submitting ? 'Signing In…' : 'Enter Your Portal'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleSignUp} className="auth-form">
            <p className="auth-intro">
              Set up your own login. Once you\u2019re in, you\u2019ll enter the invite code Francesca sent
              you to activate your program.
            </p>

            <label className="field-label" htmlFor="signup-email">
              Email
            </label>
            <input
              id="signup-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
            />

            <label className="field-label" htmlFor="signup-password">
              Password
            </label>
            <input
              id="signup-password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="new-password"
            />

            <label className="field-label" htmlFor="confirm-password">
              Confirm Password
            </label>
            <input
              id="confirm-password"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
              autoComplete="new-password"
            />

            {error && <div className="form-error">{error}</div>}

            <button type="submit" className="primary auth-submit" disabled={submitting}>
              {submitting ? 'Creating Account…' : 'Create Account'}
            </button>
          </form>
        )}
      </div>

      <style>{`
        .auth-shell {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: var(--canvas);
          padding: 1.5rem;
        }
        .auth-panel {
          width: 100%;
          max-width: 400px;
          padding: 2.5rem 0.25rem;
          text-align: center;
        }
        .auth-brand {
          display: flex;
          flex-direction: column;
          align-items: center;
          margin-bottom: 2.25rem;
        }
        .auth-script {
          font-family: var(--font-script);
          font-size: 52px;
          color: var(--crimson);
          line-height: 1;
        }
        .auth-subscript {
          font-family: var(--font-sans);
          font-size: 10px;
          letter-spacing: 0.4em;
          text-transform: uppercase;
          color: var(--ink);
          margin-top: 2px;
        }
        .auth-tabs {
          display: flex;
          justify-content: center;
          gap: 2.5rem;
        }
        .auth-rule {
          margin: 0.9rem auto 2rem;
        }
        .auth-form {
          display: flex;
          flex-direction: column;
          gap: 0.3rem;
          text-align: left;
        }
        .auth-intro {
          font-size: 0.85rem;
          margin-bottom: 0.75rem;
          text-align: left;
        }
        .field-label {
          font-family: var(--font-sans);
          font-size: 9px;
          letter-spacing: 0.22em;
          text-transform: uppercase;
          color: var(--muted);
          margin-top: 1rem;
        }
        .auth-submit {
          margin-top: 2rem;
          width: 100%;
        }
        .form-notice {
          margin-top: 0.75rem;
          font-size: 0.82rem;
          color: var(--ink-soft);
        }
      `}</style>
    </div>
  )
}
