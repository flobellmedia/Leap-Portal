# The Leap — Client Portal

A private dashboard for enrolled Leap With Francesca clients: self-service sign up, milestone tracking across the three pillars (identity, relationships, money), a resource library, and a reflection journal. Theme is pulled directly from the Leap With Francesca site — same colors, fonts, and flat/editorial style.

## 1. Set up Supabase (10 min)

1. Go to [supabase.com](https://supabase.com) and create a new project (or use an existing one).
2. In the SQL editor, paste and run everything in `supabase/schema.sql`. This creates all six pieces: `profiles`, `milestones`, `resources`, `journal_entries`, `calls`, `invites`, plus the `redeem_invite()` function.
3. Under **Authentication → Settings**, decide whether to require email confirmation on sign up. Either works with this app — if confirmation is on, new clients see a "check your email" message and then sign in normally.
4. Under **Project Settings → API**, copy your **Project URL** and **anon public key** — you'll need both in step 3 below.

## 2. How a new client gets in (self-service signup + invite code)

Since anyone with the link could otherwise create an account and see the private resource library, signup is a two-step handshake:

1. **When someone enrolls**, go to **Table editor → invites** in Supabase and add a row:
   - `code` — something like `LEAP-A7F3K9` (any unique string)
   - `email`, `full_name`
   - `program_type` — `1-month` or `4-month`
2. **Send them their code** — this pairs naturally with Email 1 or 2 of the welcome sequence ("here's your invite code to activate your program").
3. **They go to the portal and create their own account** (their own email + password, under the "Create Account" tab).
4. **Right after signing in for the first time**, they land on an "Activate Your Program" screen and enter the code. That's what creates their `profiles` row and unlocks the dashboard.

You still add their `milestones` and `calls` rows yourself in the table editor (see below) — the invite code only handles account creation and program-type assignment.

### Adding milestones, resources, and calls

- **Table editor → milestones** — one row per milestone for that client, tagged with `pillar` (`identity` / `relationships` / `money`), `title`, `week_number`.
- **Table editor → calls** — their upcoming call(s), with `scheduled_at` and `zoom_link`.
- **Table editor → resources** — shared across all clients, so you only add each resource once, not per client.

## 3. Local setup

```bash
npm install
cp .env.example .env
# then fill in your Supabase URL + anon key in .env
npm run dev
```

## 4. Deploy to Netlify as a subdomain

1. Push this project to a GitHub repo.
2. In Netlify: **Add new site → Import an existing project**, connect the repo.
3. Build settings are already set via `netlify.toml` — Netlify should detect them automatically.
4. Under **Site settings → Environment variables**, add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
5. Deploy.
6. Under **Domain settings → Add a domain**, add `portal.leapwithfrancesca.com` (or your preferred subdomain). Since flobellmedia.com is already on Netlify, this is just one DNS record.
7. Add a "Client Login" link on your main site's nav pointing to the portal.

## Notes

- Clients can toggle their own milestones, add journal entries, and redeem their own invite code — nothing else. Everything else is managed by you in the Supabase table editor for now.
- Theme tokens (`src/styles/theme.css`) are pulled straight from `src/index.css` on the main site — same crimson `#8B1A1A`, canvas `#faf8f5`, ink `#1a1410`, blush `#c4908a`, and the Playfair Display / Josefin Sans / Pinyon Script font pairing.
- If this grows past a handful of clients, the natural next step is a small admin view inside the portal so you're not hand-editing Supabase tables — happy to build that when you're ready.
